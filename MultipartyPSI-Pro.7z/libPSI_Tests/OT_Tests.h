#pragma once

void BitVector_Indexing_Test_Impl          ();
void BitVector_Parity_Test_Impl            ();
void BitVector_Append_Test_Impl            ();
void BitVector_Copy_Test_Impl            ();
void Transpose_Test_Impl                ();


void KosOtExt_100Receive_Test_Impl();
void LzKosOtExt_100Receive_Test_Impl();
void IknpOtExt_100Receive_Test_Impl();

