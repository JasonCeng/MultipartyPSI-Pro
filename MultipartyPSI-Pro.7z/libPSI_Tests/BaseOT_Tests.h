#pragma once 
void NaorPinkasOt_Test_Impl();

