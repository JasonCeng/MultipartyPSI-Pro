#pragma once

void nOPPRF_EmptrySet_Test_Impl();
void nOPPRFn_EmptrySet_Test_Impl();
void nOPPRF_EmptrySet_hashing_Test_Impl();
void nOPPRF3_EmptrySet_Test_Impl();


