#pragma once

void AknBfPsi_EmptrySet_Test_Impl  ();
void AknBfPsi_FullSet_Test_Impl    ();
void AknBfPsi_SingltonSet_Test_Impl();
//void OtBinPsi_SingltonSet_serial_Test_Impl();

