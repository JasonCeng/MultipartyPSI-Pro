#pragma once


void EccpNumber_Test();
void EccpPoint_Test();

void Ecc2mNumber_Test();
void Ecc2mPoint_Test();
