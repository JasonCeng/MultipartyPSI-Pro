#pragma once


void KkrtNcoOt_Test_Impl();
void OosNcoOt_Test_Impl();

void LinearCode_Test_Impl();
