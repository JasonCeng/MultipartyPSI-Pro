#pragma once
void OPPRF_CuckooHasher_Test_Impl();

void Bit_Position_Test_Impl();
void Bit_Position_Recursive_Test_Impl();
void OPPRF_EmptrySet_Test_Impl  ();
void Channel_Test_Impl();
void OPPRFn_EmptrySet_Test_Impl();
void hashing2Bins_Test_Impl();
void OPPRF_EmptrySet_hashing_Test_Impl();
void OPPRF3_EmptrySet_Test_Impl();
void findMaxBinSize_Test_Impl();
void findScaleNumBins_Test_Impl();
void Bit_Position_Random_Test_Impl();
void testShareValue();
void OPPRFnt_EmptrySet_Test_Impl();
void polynomial_Test_Impl();
void GBF_Test_Impl();
void OPPRF2_EmptrySet_Test_Impl();
void OPPRFn_Aug_EmptrySet_Test_Impl();
//void OPPRF_FullSet_Test_Impl    ();
//void OPPRF_SingltonSet_Test_Impl();


