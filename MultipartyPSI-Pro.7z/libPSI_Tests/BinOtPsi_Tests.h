#pragma once
void OtBinPsi_CuckooHasher_Test_Impl();


void OtBinPsi_Kkrt_EmptrySet_Test_Impl  ();
void OtBinPsi_Kkrt_FullSet_Test_Impl    ();
void OtBinPsi_Kkrt_SingltonSet_Test_Impl();



void OtBinPsi_Oos_EmptrySet_Test_Impl();
void OtBinPsi_Oos_FullSet_Test_Impl();
void OtBinPsi_Oos_SingltonSet_Test_Impl();
//void OtBinPsi_SingltonSet_serial_Test_Impl();

