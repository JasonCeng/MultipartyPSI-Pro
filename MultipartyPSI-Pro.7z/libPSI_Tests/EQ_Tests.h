#pragma once

void EQ_EmptrySet_Test_Impl();
