




    void BtNetwork_Connect1_Boost_Test();
    void BtNetwork_OneMegabyteSend_Boost_Test();
    void BtNetwork_ConnectMany_Boost_Test();
    void BtNetwork_CrossConnect_Test();
    void BtNetwork_ManyEndpoints_Test();

