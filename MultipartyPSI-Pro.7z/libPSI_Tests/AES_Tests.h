#pragma once


void AES_EncDec_Test();
