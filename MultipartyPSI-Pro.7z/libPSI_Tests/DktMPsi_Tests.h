#pragma once

void DktMPsi_EmptrySet_Test_Impl  ();
void DktMPsi_FullSet_Test_Impl    ();
void DktMPsi_SingltonSet_Test_Impl();
//void OtBinPsi_SingltonSet_serial_Test_Impl();

