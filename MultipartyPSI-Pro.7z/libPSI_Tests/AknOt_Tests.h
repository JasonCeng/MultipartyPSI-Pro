#pragma once


void AknOt_sendRecv1000_Test();