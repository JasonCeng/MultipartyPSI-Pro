cd .\win\

.\getBoost.ps1 
.\getMiracl.ps1 
.\getNTL.ps1

echo "all done!"